import interfaz.PrincipalJuego;

public class Main {

    
    public static void main(String[] args) {
        PrincipalJuego pj = new PrincipalJuego();
        
    }

}
