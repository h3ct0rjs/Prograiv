/*
 * AcercaDe.java
 *
 * Descripcion: Informacion acerca del programa.
 */
 package interfaz;


import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;

 /**
 *
 * @author Freddy Gonz�lez
 */

class AcercaDe extends JDialog implements ActionListener {

    //Declarar Variables
    private JButton cerrar;


    AcercaDe(){
        //Propiedades del JDialog
        this.setTitle("Informacion");
        this.setLayout(null);
        this.setSize(450,170);
        this.setResizable(false);
        JLabel version,autor,descripcion,titulo;

		this.setLocationRelativeTo(null);
		
        //Texto Central
        titulo = new JLabel("Programacion 4");
        add(titulo);
        titulo.setBounds(10, 10, 350, 27);
        titulo.setFont(new Font("Titulo",Font.BOLD + Font.ITALIC,22));

        version = new JLabel("Codigo: 1088537696; 1115421345");
        version.setBounds(40, 70, 350, 15);
        add(version);

        autor = new JLabel("Autor: Daniel C. Quiroz; Hector F Jimenez");
        autor.setBounds(40, 100, 350, 15);
        add(autor);

        descripcion = new JLabel("Juego de damas.");
        descripcion.setBounds(30, 40, 350, 15);
        add(descripcion);


        //Creando Botones.
        cerrar = new JButton("Aceptar");
        add(cerrar);
        cerrar.setBounds(350,115,80,22);
        cerrar.addActionListener(this);
    }

    public void actionPerformed(ActionEvent arg0) {
        //Accion del boton Cerrar
        this.dispose();
    }


}
