package interfaz;

import damas.Tablero;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class JuegoNuevo extends JDialog implements ActionListener {
	private Tablero tab;
	private JLabel rojas, negras;
	private JButton aceptar, cancelar;
	private String[] modos = {
			"2 Jugadores",
			"Rojas",
			"Negras",
			"Demo"
		};
	private JComboBox comboModos;
	JuegoNuevo(Tablero t){
		tab = t;
		
		this.setTitle("Nuevo Juego");
		setSize(300,100);
		setLocationRelativeTo(null);
		setResizable(false);
		setLayout(new FlowLayout());
		setModal(true);
		
		modos = new String[] {
			"2 Jugadores",
			"Rojas",
			"Negras",
			"Demo"
		};
		
		rojas = new JLabel("Rojas - ");
		negras = new JLabel(" - Negras");
		comboModos = new JComboBox(modos);
		aceptar = new JButton("Comenzar Juego");
		cancelar = new JButton("Cancelar");
		
		comboModos.setEditable(false);
		
		add(rojas);
		add(comboModos);
		add(negras);
		add(aceptar);
		add(cancelar);
		
		aceptar.addActionListener(this);
		cancelar.addActionListener(this);
		
		repaint();
		
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource().equals(aceptar)){
			tab.comenzarPartida(comboModos.getSelectedIndex());
		}
		
		comboModos.setSelectedIndex(0);
		this.dispose();
		
	}
}
